import { XL } from '@zendeskgarden/react-typography'
import { useI18n } from '../hooks/useI18n'
import TicketSideBar from './TicketSideBar'

const Modal = () => {
  return (
    <div>
      
      <TicketSideBar />
    </div>
  )
}

export default Modal
