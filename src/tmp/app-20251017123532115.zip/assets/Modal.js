import{j as r}from"./main.js";import t from"./TicketSideBar.js";import"./ContactList.js";const s=()=>r.jsx("div",{children:r.jsx(t,{})});export{s as default};
