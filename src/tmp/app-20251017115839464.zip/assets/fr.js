const t={title:"Bonjour du Ticket Side Bar"},o={title:"Bonjour du Modal"},e={ticket_sidebar:t,modal:o};export{e as default,o as modal,t as ticket_sidebar};
